#ifndef UDP_SOCKET_H
#define UDP_SOCKET_H
#include "base_socket.h"

class UdpSocket:public BaseSocket
{
public:
	UdpSocket(const char* ip,uint16_t port):BaseSocket(SOCK_DGRAM,ip,port) {}
	
	int recv(void* buf,uint32_t len)
	{
		return recvfrom(fd,buf,len,0,(SP)&addr,&addrlen);
	}
	
	int send(void* buf,uint32_t len)
	{
		return sendto(fd,buf,len,0,(SP)&addr,addrlen);
	}
	
	int send(const char* buf)
	{
		return sendto(fd,buf,strlen(buf),0,(SP)&addr,addrlen);
	}
};

class UdpServer:public UdpSocket
{
public:
	UdpServer(const char* ip,uint16_t port):UdpSocket(ip,port)
	{
		if(bind(fd,(SP)&addr,addrlen))
    	{
        	perror("UdpServer bind");
    	}
	}
};

class UdpClient:public UdpSocket
{
public:
	UdpClient(const char* ip,uint16_t port):UdpSocket(ip,port)
	{
		if(connect(fd,(SP)&addr,addrlen))
    	{
        	perror("UdpClient connect");
    	}
	}
};

#endif//UDP_SOCKET_H
