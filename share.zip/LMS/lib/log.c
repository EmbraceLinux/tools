#include "log.h"

// 定义存储日志级别的全局变量
LOG_LEVEL log_level = LOG_INFO;

// 定义日志文件指针
FILE* ifp = stdout;
FILE* wfp = stdout;
FILE* efp = stderr;
FILE* ffp = stderr;

// 设置日志信息的显示级别
void set_log_level(const char* level)
{
	if(0 == strcmp("LOG_FATAL",level))
		log_level = LOG_FATAL;
	else if(0 == strcmp("LOG_ERROR",level))
		log_level = LOG_ERROR;
	else if(0 == strcmp("LOG_WARNING",level))
		log_level = LOG_WARNING;
}

// 设置日志文件文件的路径
int set_log_path(const char* log_path,const char* program)
{
	// 打开日志文件，提示、警告、错误、致命错误的相关信息就会记录在文件
	char path[4096] = {};
	sprintf(path,"%s/%s_info.log",log_path,program);
	ifp = fopen(path,"a");
	sprintf(path,"%s/%s_warning.log",log_path,program);
	wfp = fopen(path,"a");
	sprintf(path,"%s/%s_error.log",log_path,program);
	efp = fopen(path,"a");
	sprintf(path,"%s/%s_fatal.log",log_path,program);
	ffp = fopen(path,"a");
	if(NULL==ifp || NULL==wfp || NULL==efp || NULL==ffp)
	{
		perror("log_init");
		return -1;
	}
	
	return 0;
}
