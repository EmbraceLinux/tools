#include "xml_doc_parse.h"

XmlDocParse::XmlDocParse(const char* path):path(path)
{	
	// 如果提供有效的xml文件路径，则自动解析xml文件
	if(NULL != path)
    {	
    	doc = new TiXmlDocument(path);
    	parse();
    }
    else
    {
    	doc = NULL;
    }
}

XmlDocParse::~XmlDocParse(void)
{
    delete doc;
}

void XmlDocParse::parse(void)
{
	// 检查文件是否存在
    if(!doc->LoadFile())
    {
        printf("load file %s , Error='%s'\n", path,doc->ErrorDesc());
        return;
    }

	// 获取根对象
    TiXmlElement* rootElement = doc->RootElement();
    if(NULL == rootElement)
    {
        printf("config.xml is empty!");
        return;
    }

	// 可能不是首次解析，因此清理env
    env.clear();
    // 遍历子对象
    for(TiXmlElement* i=rootElement->FirstChildElement(); NULL!=i; i=i->NextSiblingElement())
    {
		// 遍历子对象的子对象
        for(TiXmlElement* j=i->FirstChildElement(); NULL!=j; j=j->NextSiblingElement())
        {
        	// 把对象名和对象值插入到map容器中
            env.insert(make_pair(j->Value(),j->GetText()));
        }
    }
}

void XmlDocParse::setPath(const char* path)
{
	// 如果doc为NULL则不会出错，如果doc已经被创建则先释放
    delete doc;
    // 记录xml文件地址
    this->path = path;
    // 创建doc对象
    doc = new TiXmlDocument(path);
    // 解析
    parse();

}

const char* XmlDocParse::getValue(string name)
{
	// 创建一个迭代器，记录查询结果
    map<string,string>::iterator it = env.find(name);
    // 如果迭代器指向容器的最后一个元素的后面，则说明没有找到
    if(it == env.end())
        return NULL;
    else
    	// 返回迭代器的第二项数据
        return it->second.c_str();
}
