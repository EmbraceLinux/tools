#include <stdlib.h>
#include <string.h>
#include "json.h"

JSON::JSON(void)
{
	root = cJSON_CreateObject();
	str = NULL;
}

JSON::~JSON(void)
{
	cJSON_Delete(root);
	root = NULL;

	free(str);
	str = NULL;
}

void JSON::setRoot(cJSON* root)
{
	this->root = root;
}

const char* JSON::getStr(void)
{
	free(str);
	str = cJSON_Print(root);
	if(NULL == str)
	{
        printf("cJSON error %s\n",cJSON_GetErrorPtr());
	}
	return str;
}

cJSON* JSON::getRoot(void)
{
    return root;
}

bool JSON::parse(const char* json_str)
{
	cJSON_Delete(root);
	free(str);
	str = NULL;

	root = cJSON_Parse(json_str);
	if(NULL == root)
	{
        printf("cJSON error %s\n",cJSON_GetErrorPtr());
		return false;
	}

	return true;
}

void JSON::addObject(const char* name,const char* data)
{
    cJSON_AddStringToObject(root,name,data);
}

void JSON::addObject(const char* name,bool data)
{
    cJSON_AddBoolToObject(root,name,data);
}

void JSON::addSubJSON(const char* name,JSON& obj)
{
    cJSON_AddItemToObject(root, name, obj.getRoot());
}

bool JSON::getObject(const char* name,char* data)
{
	cJSON* obj = cJSON_GetObjectItem(root,name);
	if(NULL == obj)
	{
        printf("cJSON error %s\n",cJSON_GetErrorPtr());
		return false;
	}
	strcpy(data,obj->valuestring);
	return true;
}

bool JSON::getObject(const char* name,double& data)
{
	cJSON* obj = cJSON_GetObjectItem(root,name);
	if(NULL == obj)
	{
        printf("cJSON error %s\n",cJSON_GetErrorPtr());
		return false;
	}
	data = obj->valuedouble;
	return true;
}

JSON* JSON::getSubJSON(const char* name)
{
	cJSON* obj = cJSON_GetObjectItem(root,name);
	if(NULL == obj)
	{
        printf("cJSON error %s\n",cJSON_GetErrorPtr());
		return NULL;
	}
	JSON* json = new JSON;
	json->setRoot(obj);
	return json;
}

