模块介绍：
	xml：读取服务器或客户端的配置文件
	json：用于类对象与字符串之间的转换
	md5：用于存储用户密码，或验证文件的完整性
	log：用于记录程序运行时的，操作、提醒、警告、错误
	mysql：用于连接、操作数据库，并获取结果
	network：用于客户端与服务器之间网络通信，封装socket。
	threadpool：线程池，生产者与消费者模型
	lib：以上模块编译成相应的库文件，存储到lib中
	include：以模块的相关头文件，存储到include
	server：服务器模块
	client：客户端模块
	
准备工作：
	1、编译生成共享库，共享库文件存储在lib中，头文件存储在include中，编译时设置编译参数
		-I 指定头文件的路径
		-L 指定库文件的路径
		-l 指定一起编译地库名
		
	2、设计数据表
		超级用户：admin qweroiu1240AERwweroj
		管理员：manager(id int,pw char(8));
		会员：vip(tel char(11),ya float,yu float);
		图书表：create table book(isbn char(20),name varchar(256),type char(10),author char(50),	price float,press varchar(256),cnt int);
		借书表：borrow(tel char(11),isbn char(20),begin date);
		评分表：evaluate(isbn char(20),tel char(11),star float,mark varchar(4096));
	3、设计消息格式
		C to S
		{
			object:admin|manager|guest|config
			opt:
			data:
			{
			
			}
		}
		
		S to C
		{
			object:admin|manager|guest|config
			opt:
			result:ok|no
		}
		注意：特殊的操作会随之发送一系列数据
服务器端的实现：
	
		
