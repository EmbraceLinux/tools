#include "server_lms.h"
#include "admin.h"
#include "guest.h"
#include "manager.h"

ServerLMS::ServerLMS(void)
{
	threadPool = new ThreadPool<TcpSocket*>(threadRun,atoi(xml->getValue("pthread_count")));
	tcpServer = new TcpServer(xml->getValue("server_ip"),atoi(xml->getValue("server_port")));
}

ServerLMS::~ServerLMS(void)
{
	threadPool->stop();
	delete threadPool;
	delete tcpServer;
}

void* ServerLMS::threadRun(void* arg)
{
	ThreadPool<TcpSocket*>* threadPool = (ThreadPool<TcpSocket*>*)arg;
	Admin admin;
	Guest guest;
	Manager mgr;
	
	for(;;)
	{
		TcpSocket* tcpSocket = threadPool->popTask();
		admin.setTcpSocket(tcpSocket);
		guest.setTcpSocket(tcpSocket);
		mgr.setTcpSocket(tcpSocket);
		for(;;)
		{
			char buf[4096] = {};
			int ret = tcpSocket->recv(buf,sizeof(buf));
			if(0 >= ret)
			{
				ilog("客户端断开连接...\n");
				delete tcpSocket;
				break;
			}
			ilog("%s\n",buf);
			if(strstr(buf,"admin"))
				admin.setJSON(buf);
			else if(strstr(buf,"guest"))
				guest.setJSON(buf);
			else if(strstr(buf,"manager"))
				guest.setJSON(buf);
			else
				tcpSocket->send("数据格式有误！！！");
		}
		
	}
	
	return NULL;
}

void ServerLMS::start(void)
{
	threadPool->start();
	
	for(;;)
	{
		ilog("开始等待客户端连接...\n");
		TcpSocket* tcpSocket = tcpServer->accept();
		threadPool->pushTask(tcpSocket);				
	}
}
