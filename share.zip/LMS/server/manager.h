#ifndef MANAGER_H
#define MANAGER_H
#include <json.h>
#include <tcp_socket.h>

class Manager
{
	JSON* json;
	TcpSocket* tcpSocket;
public:
	Manager(void);
	~Manager(void);
	void setJSON(const char* str);
	void setTcpSocket(TcpSocket* tcpSocket);
};

#endif//MANAGER_H
