#include "guest.h"

Guest::Guest(void)
{

}

Guest::~Guest(void)
{

}

void Guest::setJSON(const char* str)
{

}

void Guest::setTcpSocket(TcpSocket* tcpSocket)
{
	this->tcpSocket = tcpSocket;
}
