#include "manager.h"

Manager::Manager(void)
{

}

Manager::~Manager(void)
{

}

void Manager::setJSON(const char* str)
{

}

void Manager::setTcpSocket(TcpSocket* tcpSocket)
{
	this->tcpSocket = tcpSocket;
}
