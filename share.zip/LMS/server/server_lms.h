#ifndef SERVER_LMS_H
#define SERVER_LMS_H
#include <log.h>
#include <sql.h>
#include <tcp_socket.h>
#include <threadpool.h>
#include <xml_doc_parse.h>

extern XmlDocParse* xml;
extern SQL* sql;

class ServerLMS
{
	TcpServer* tcpServer;
	ThreadPool<TcpSocket*>* threadPool;
public:
	ServerLMS(void);
	~ServerLMS(void);
	static void* threadRun(void* arg);
	void start(void);
};

#endif//SERVER_LMS_H
