#ifndef GUEST_H
#define GUEST_H
#include <tcp_socket.h>
#include <json.h>

class Guest
{
	JSON* json;
	TcpSocket* tcpSocket;
public:
	Guest(void);
	~Guest(void);
	void setJSON(const char* str);
	void setTcpSocket(TcpSocket* tcpSocket);
};
#endif//GUEST_H
