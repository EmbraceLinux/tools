#include "admin.h"

Admin::Admin(void)
{

}

Admin::~Admin(void)
{

}

void Admin::setJSON(const char* str)
{

}

void Admin::setTcpSocket(TcpSocket* tcpSocket)
{
	this->tcpSocket = tcpSocket;
}
