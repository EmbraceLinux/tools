#include <signal.h>
#include "server_lms.h"

ServerLMS* serverLMS;
XmlDocParse* xml;
SQL* sql;

void sigint(int signum)
{
	exit(0);
	delete serverLMS;
	delete sql;
	delete xml;	
}

int main(int argc,char* argv[])
{
	signal(SIGINT,sigint);
	
	xml = new XmlDocParse("config.xml");
	set_log_level(xml->getValue("log_level"));
	//set_log_path(xml->getValue("log_path"),argv[0]);
	
	sql = new SQL(xml->getValue("database_host"),xml->getValue("database_user"),xml->getValue("database_password"),xml->getValue("database_name"),atoi(xml->getValue("database_port")));
	
	serverLMS = new ServerLMS;
	serverLMS->start();	
}
