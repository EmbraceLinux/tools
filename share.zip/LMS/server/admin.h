#ifndef ADMIN_H
#define ADMIN_H
#include <json.h>
#include <tcp_socket.h>

class Admin
{
	JSON* json;
	TcpSocket* tcpSocket;
public:
	Admin(void);
	~Admin(void);
	void setJSON(const char* str);
	void setTcpSocket(TcpSocket* tcpSocket);
};

#endif//ADMIN_H
