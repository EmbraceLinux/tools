create table manager(id int,pw char(8));--管理员
create table vip(tel char(11),ya float,yu float);--会员
create table book(isbn char(20),name varchar(256),type char(10),author char(50),	price float,press varchar(256),cnt int);--图书表
create table borrow(tel char(11),isbn char(20),begin date);--借书表
create table evaluate(isbn char(20),tel char(11),star float,mark varchar(4096));--评分表
