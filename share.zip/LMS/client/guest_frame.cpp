#include "guest_frame.h"
#include "ui_guest_frame.h"
#include "json.h"

GuestFrame::GuestFrame(QWidget *parent) :
    QFrame(parent),
    ui(new Ui::GuestFrame)
{
    ui->setupUi(this);
}

GuestFrame::~GuestFrame()
{
    delete ui;
}

void GuestFrame::on_rollback_btn_clicked()
{
    this->hide();
}

void GuestFrame::on_select_btn_clicked()
{
    JSON* j1 = new JSON;
    j1->addObject("object","guest");
    j1->addObject("opt","select");
    j1->addObject("keywork",ui->keyword_edit->text().toStdString().c_str());
    if(ui->star_radio->isChecked())
    {
        j1->addObject("type","start");
    }
    else if(ui->mark_radio->isChecked())
    {
        j1->addObject("type","mark");
    }
    else
    {
        j1->addObject("type","cnt");
    }

    qDebug("json:%s",j1->getStr());
}
