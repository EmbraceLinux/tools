#ifndef CONFIG_FRAME_H
#define CONFIG_FRAME_H

#include <QFrame>

namespace Ui {
class ConfigFrame;
}

class ConfigFrame : public QFrame
{
    Q_OBJECT
    
public:
    char ip[16];
    ushort port;
    explicit ConfigFrame(QWidget *parent = 0);
    ~ConfigFrame();
    
private slots:
    void on_rollback_btn_clicked();

    void on_save_reboo_btn_clicked();

private:
    Ui::ConfigFrame *ui;
};

#endif // CONFIG_FRAME_H
