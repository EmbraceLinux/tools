#include "main_widget.h"
#include "ui_main_widget.h"

QTcpSocket* tcpSocket;

MainWidget::MainWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MainWidget)
{
    // 加载配置文件

    ui->setupUi(this);
    adminFrame = new AdminFrame(this);
    adminFrame->hide();
    mgrFrame = new MgrFrame(this);
    mgrFrame->hide();
    guestFrame = new GuestFrame(this);
    guestFrame->hide();
    configFrame = new ConfigFrame(this);
    configFrame->hide();

    tcpSocket = new QTcpSocket;
    connect(tcpSocket,SIGNAL(connected()),this,SLOT(connect_server_success()));
    connect(tcpSocket,SIGNAL(error(QAbstractSocket::SocketError)),this,SLOT(connect_server_error(QAbstractSocket::SocketError)));
    tcpSocket->connectToHost(configFrame->ip,configFrame->port);
    tcpSocket->waitForConnected();
}

MainWidget::~MainWidget()
{
    delete ui;
}

void MainWidget::on_admin_btn_clicked()
{
    adminFrame->show();
}

void MainWidget::on_mgr_btn_clicked()
{
    mgrFrame->show();
}

void MainWidget::on_guest_btn_clicked()
{
    guestFrame->show();
}

void MainWidget::on_config_btn_clicked()
{
    configFrame->show();
}

void MainWidget::connect_server_success()
{

}

void MainWidget::connect_server_error(QAbstractSocket::SocketError err)
{
    on_config_btn_clicked();
}


