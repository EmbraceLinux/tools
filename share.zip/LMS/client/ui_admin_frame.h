/********************************************************************************
** Form generated from reading UI file 'admin_frame.ui'
**
** Created: Tue Sep 24 11:38:57 2019
**      by: Qt User Interface Compiler version 4.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADMIN_FRAME_H
#define UI_ADMIN_FRAME_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QFrame>
#include <QtGui/QHeaderView>
#include <QtGui/QLineEdit>
#include <QtGui/QListWidget>
#include <QtGui/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_AdminFrame
{
public:
    QPushButton *rollback_btn;
    QPushButton *delMgr_btn;
    QPushButton *addMgr_btn;
    QPushButton *reSetPW_btn;
    QPushButton *listAllMgr_btn;
    QLineEdit *delMgr_edit;
    QLineEdit *reSetPW_edit;
    QListWidget *listAllMgr_widget;

    void setupUi(QFrame *AdminFrame)
    {
        if (AdminFrame->objectName().isEmpty())
            AdminFrame->setObjectName(QString::fromUtf8("AdminFrame"));
        AdminFrame->resize(700, 400);
        AdminFrame->setStyleSheet(QString::fromUtf8("QFrame\n"
"{\n"
"	background-color: rgb(236, 235, 234);\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"	background-color: qconicalgradient(cx:0.5, cy:0.522909, angle:179.9, stop:0.494318 rgba(181, 225, 250, 255), stop:0.5 rgba(222, 242, 251, 255));\n"
"	border-radius:5px;\n"
"	border: 1px solid #3C80B1;  \n"
"}\n"
"\n"
"QPushButton:pressed\n"
"{\n"
"	background-color: qconicalgradient(cx:0.5, cy:0.522909, angle:179.9, stop:0.494318 rgba(134, 198, 233, 255), stop:0.5 rgba(206, 234, 248, 255));\n"
"	border-radius:5px;\n"
"	border: 1px solid #5F92B2;  \n"
"}"));
        AdminFrame->setFrameShape(QFrame::StyledPanel);
        AdminFrame->setFrameShadow(QFrame::Raised);
        rollback_btn = new QPushButton(AdminFrame);
        rollback_btn->setObjectName(QString::fromUtf8("rollback_btn"));
        rollback_btn->setGeometry(QRect(590, 360, 98, 27));
        delMgr_btn = new QPushButton(AdminFrame);
        delMgr_btn->setObjectName(QString::fromUtf8("delMgr_btn"));
        delMgr_btn->setGeometry(QRect(190, 110, 98, 27));
        addMgr_btn = new QPushButton(AdminFrame);
        addMgr_btn->setObjectName(QString::fromUtf8("addMgr_btn"));
        addMgr_btn->setGeometry(QRect(360, 80, 98, 27));
        reSetPW_btn = new QPushButton(AdminFrame);
        reSetPW_btn->setObjectName(QString::fromUtf8("reSetPW_btn"));
        reSetPW_btn->setGeometry(QRect(180, 260, 98, 27));
        listAllMgr_btn = new QPushButton(AdminFrame);
        listAllMgr_btn->setObjectName(QString::fromUtf8("listAllMgr_btn"));
        listAllMgr_btn->setGeometry(QRect(490, 80, 98, 27));
        delMgr_edit = new QLineEdit(AdminFrame);
        delMgr_edit->setObjectName(QString::fromUtf8("delMgr_edit"));
        delMgr_edit->setGeometry(QRect(50, 110, 113, 27));
        reSetPW_edit = new QLineEdit(AdminFrame);
        reSetPW_edit->setObjectName(QString::fromUtf8("reSetPW_edit"));
        reSetPW_edit->setGeometry(QRect(40, 260, 113, 27));
        listAllMgr_widget = new QListWidget(AdminFrame);
        listAllMgr_widget->setObjectName(QString::fromUtf8("listAllMgr_widget"));
        listAllMgr_widget->setGeometry(QRect(355, 110, 321, 181));
        listAllMgr_widget->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        retranslateUi(AdminFrame);

        QMetaObject::connectSlotsByName(AdminFrame);
    } // setupUi

    void retranslateUi(QFrame *AdminFrame)
    {
        AdminFrame->setWindowTitle(QApplication::translate("AdminFrame", "Frame", 0, QApplication::UnicodeUTF8));
        rollback_btn->setText(QApplication::translate("AdminFrame", "<<--", 0, QApplication::UnicodeUTF8));
        delMgr_btn->setText(QApplication::translate("AdminFrame", "\345\210\240\351\231\244\347\256\241\347\220\206\345\221\230", 0, QApplication::UnicodeUTF8));
        addMgr_btn->setText(QApplication::translate("AdminFrame", "\346\267\273\345\212\240\347\256\241\347\220\206\345\221\230", 0, QApplication::UnicodeUTF8));
        reSetPW_btn->setText(QApplication::translate("AdminFrame", "\351\207\215\345\233\264\345\257\206\347\240\201", 0, QApplication::UnicodeUTF8));
        listAllMgr_btn->setText(QApplication::translate("AdminFrame", "\345\210\227\345\207\272\347\256\241\347\220\206\345\221\230", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class AdminFrame: public Ui_AdminFrame {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADMIN_FRAME_H
