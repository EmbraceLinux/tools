/********************************************************************************
** Form generated from reading UI file 'guest_frame.ui'
**
** Created: Tue Sep 24 17:18:11 2019
**      by: Qt User Interface Compiler version 4.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GUEST_FRAME_H
#define UI_GUEST_FRAME_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QFrame>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QListWidget>
#include <QtGui/QPushButton>
#include <QtGui/QRadioButton>

QT_BEGIN_NAMESPACE

class Ui_GuestFrame
{
public:
    QPushButton *rollback_btn;
    QLabel *label;
    QLineEdit *keyword_edit;
    QPushButton *select_btn;
    QListWidget *result_list;
    QRadioButton *star_radio;
    QRadioButton *mark_radio;
    QRadioButton *cnt_radio;

    void setupUi(QFrame *GuestFrame)
    {
        if (GuestFrame->objectName().isEmpty())
            GuestFrame->setObjectName(QString::fromUtf8("GuestFrame"));
        GuestFrame->resize(700, 400);
        GuestFrame->setStyleSheet(QString::fromUtf8("QFrame\n"
"{\n"
"	background-color: rgb(236, 235, 234);\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"	background-color: qconicalgradient(cx:0.5, cy:0.522909, angle:179.9, stop:0.494318 rgba(181, 225, 250, 255), stop:0.5 rgba(222, 242, 251, 255));\n"
"	border-radius:5px;\n"
"	border: 1px solid #3C80B1;  \n"
"}\n"
"\n"
"QPushButton:pressed\n"
"{\n"
"	background-color: qconicalgradient(cx:0.5, cy:0.522909, angle:179.9, stop:0.494318 rgba(134, 198, 233, 255), stop:0.5 rgba(206, 234, 248, 255));\n"
"	border-radius:5px;\n"
"	border: 1px solid #5F92B2;  \n"
"}"));
        GuestFrame->setFrameShape(QFrame::StyledPanel);
        GuestFrame->setFrameShadow(QFrame::Raised);
        rollback_btn = new QPushButton(GuestFrame);
        rollback_btn->setObjectName(QString::fromUtf8("rollback_btn"));
        rollback_btn->setGeometry(QRect(590, 360, 98, 27));
        label = new QLabel(GuestFrame);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(110, 70, 66, 17));
        keyword_edit = new QLineEdit(GuestFrame);
        keyword_edit->setObjectName(QString::fromUtf8("keyword_edit"));
        keyword_edit->setGeometry(QRect(190, 70, 211, 27));
        select_btn = new QPushButton(GuestFrame);
        select_btn->setObjectName(QString::fromUtf8("select_btn"));
        select_btn->setGeometry(QRect(420, 70, 98, 27));
        result_list = new QListWidget(GuestFrame);
        result_list->setObjectName(QString::fromUtf8("result_list"));
        result_list->setGeometry(QRect(80, 140, 461, 221));
        result_list->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        star_radio = new QRadioButton(GuestFrame);
        star_radio->setObjectName(QString::fromUtf8("star_radio"));
        star_radio->setGeometry(QRect(130, 100, 116, 22));
        star_radio->setChecked(true);
        mark_radio = new QRadioButton(GuestFrame);
        mark_radio->setObjectName(QString::fromUtf8("mark_radio"));
        mark_radio->setGeometry(QRect(270, 100, 116, 22));
        cnt_radio = new QRadioButton(GuestFrame);
        cnt_radio->setObjectName(QString::fromUtf8("cnt_radio"));
        cnt_radio->setGeometry(QRect(400, 100, 116, 22));

        retranslateUi(GuestFrame);

        QMetaObject::connectSlotsByName(GuestFrame);
    } // setupUi

    void retranslateUi(QFrame *GuestFrame)
    {
        GuestFrame->setWindowTitle(QApplication::translate("GuestFrame", "Frame", 0, QApplication::UnicodeUTF8));
        rollback_btn->setText(QApplication::translate("GuestFrame", "<<--", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("GuestFrame", "\346\220\234\347\264\242\350\257\215", 0, QApplication::UnicodeUTF8));
        select_btn->setText(QApplication::translate("GuestFrame", "\346\237\245\350\257\242", 0, QApplication::UnicodeUTF8));
        star_radio->setText(QApplication::translate("GuestFrame", "Star", 0, QApplication::UnicodeUTF8));
        mark_radio->setText(QApplication::translate("GuestFrame", "mark", 0, QApplication::UnicodeUTF8));
        cnt_radio->setText(QApplication::translate("GuestFrame", "cnt", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class GuestFrame: public Ui_GuestFrame {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GUEST_FRAME_H
