#ifndef ADMIN_FRAME_H
#define ADMIN_FRAME_H

#include <QFrame>

namespace Ui {
class AdminFrame;
}

class AdminFrame : public QFrame
{
    Q_OBJECT
    
public:
    explicit AdminFrame(QWidget *parent = 0);
    ~AdminFrame();
    // 接收服务端的处理结果
    void recv_server_result(void);
    
private slots:
    void on_rollback_btn_clicked();

    void on_delMgr_btn_clicked();

    void on_reSetPW_btn_clicked();

    void on_addMgr_btn_clicked();

    void on_listAllMgr_btn_clicked();

private:
    Ui::AdminFrame *ui;
};

#endif // ADMIN_FRAME_H
