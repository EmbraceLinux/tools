#include <stdio.h>
#include <signal.h>
#include "config_frame.h"
#include "ui_config_frame.h"

ConfigFrame::ConfigFrame(QWidget *parent) :
    QFrame(parent),
    ui(new Ui::ConfigFrame)
{
    ui->setupUi(this);
    FILE* configFP = fopen(".config.txt","r");
    if(NULL == configFP)
    {
        qDebug("首次运行程序");
        return;
    }

    char buf[16] = {};
    fscanf(configFP,"%s",buf);
    ui->serverIP_edit->setText(buf);
    strcpy(ip,buf);
    fscanf(configFP,"%s",buf);
    ui->serverPort_edit->setText(buf);
    port = ui->serverPort_edit->text().toUShort();
}

ConfigFrame::~ConfigFrame()
{
    delete ui;
}

void ConfigFrame::on_rollback_btn_clicked()
{
    this->hide();
}

void ConfigFrame::on_save_reboo_btn_clicked()
{
    FILE* configFP = fopen(".config.txt","w");
    fprintf(configFP,"%s\n",ui->serverIP_edit->text().toStdString().c_str());
    fprintf(configFP,"%s\n",ui->serverPort_edit->text().toStdString().c_str());
    fclose(configFP);
    system("./client -&");
    exit(0);
}
