#ifndef GUEST_FRAME_H
#define GUEST_FRAME_H

#include <QFrame>

namespace Ui {
class GuestFrame;
}

class GuestFrame : public QFrame
{
    Q_OBJECT
    
public:
    explicit GuestFrame(QWidget *parent = 0);
    ~GuestFrame();
    
private slots:
    void on_rollback_btn_clicked();

    void on_select_btn_clicked();

private:
    Ui::GuestFrame *ui;
};

#endif // GUEST_FRAME_H
