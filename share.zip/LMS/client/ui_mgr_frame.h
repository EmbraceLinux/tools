/********************************************************************************
** Form generated from reading UI file 'mgr_frame.ui'
**
** Created: Tue Sep 24 16:18:59 2019
**      by: Qt User Interface Compiler version 4.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MGR_FRAME_H
#define UI_MGR_FRAME_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QFrame>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_MgrFrame
{
public:
    QPushButton *rollback_btn;
    QLabel *tel_borror_lab;
    QLineEdit *tel_borrow_edit;
    QLabel *isbn_borrow_lab;
    QLineEdit *isbn_borrow_edit;
    QPushButton *borrow_btn;
    QLabel *isbn_insert_lab;
    QLineEdit *isbn_insert_edit;
    QLabel *cnt_insert_lab;
    QLineEdit *cnt_insert_edit;
    QPushButton *insert_btn;
    QPushButton *destory_btn;
    QLabel *isbn_destory_lab;
    QLabel *cnt_destory_lab;
    QLineEdit *cnt_destory_edit;
    QLineEdit *isbn_destory_edit;
    QLineEdit *tel_ret_edit;
    QPushButton *ret_btn;
    QLabel *tel_ret_lab;
    QLabel *isbn_ret_lab;
    QLineEdit *isbn_ret_edit;
    QLabel *star_ret_lab;
    QLineEdit *star_ret_edit;
    QTextEdit *mark_ret_txt;
    QPushButton *add_btn;
    QLabel *tel_add_lab;
    QLabel *ya_add_lab;
    QLineEdit *ya_add_edit;
    QLineEdit *tel_add_edit;
    QLineEdit *yu_add_edit;
    QLabel *yu_add_lab;

    void setupUi(QFrame *MgrFrame)
    {
        if (MgrFrame->objectName().isEmpty())
            MgrFrame->setObjectName(QString::fromUtf8("MgrFrame"));
        MgrFrame->resize(700, 400);
        MgrFrame->setStyleSheet(QString::fromUtf8("QFrame\n"
"{\n"
"	background-color: rgb(236, 235, 234);\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"	background-color: qconicalgradient(cx:0.5, cy:0.522909, angle:179.9, stop:0.494318 rgba(181, 225, 250, 255), stop:0.5 rgba(222, 242, 251, 255));\n"
"	border-radius:5px;\n"
"	border: 1px solid #3C80B1;  \n"
"}\n"
"\n"
"QPushButton:pressed\n"
"{\n"
"	background-color: qconicalgradient(cx:0.5, cy:0.522909, angle:179.9, stop:0.494318 rgba(134, 198, 233, 255), stop:0.5 rgba(206, 234, 248, 255));\n"
"	border-radius:5px;\n"
"	border: 1px solid #5F92B2;  \n"
"}"));
        MgrFrame->setFrameShape(QFrame::StyledPanel);
        MgrFrame->setFrameShadow(QFrame::Raised);
        rollback_btn = new QPushButton(MgrFrame);
        rollback_btn->setObjectName(QString::fromUtf8("rollback_btn"));
        rollback_btn->setGeometry(QRect(590, 360, 98, 27));
        tel_borror_lab = new QLabel(MgrFrame);
        tel_borror_lab->setObjectName(QString::fromUtf8("tel_borror_lab"));
        tel_borror_lab->setGeometry(QRect(40, 30, 66, 17));
        tel_borrow_edit = new QLineEdit(MgrFrame);
        tel_borrow_edit->setObjectName(QString::fromUtf8("tel_borrow_edit"));
        tel_borrow_edit->setGeometry(QRect(80, 30, 113, 27));
        isbn_borrow_lab = new QLabel(MgrFrame);
        isbn_borrow_lab->setObjectName(QString::fromUtf8("isbn_borrow_lab"));
        isbn_borrow_lab->setGeometry(QRect(230, 30, 66, 17));
        isbn_borrow_edit = new QLineEdit(MgrFrame);
        isbn_borrow_edit->setObjectName(QString::fromUtf8("isbn_borrow_edit"));
        isbn_borrow_edit->setGeometry(QRect(290, 30, 113, 27));
        borrow_btn = new QPushButton(MgrFrame);
        borrow_btn->setObjectName(QString::fromUtf8("borrow_btn"));
        borrow_btn->setGeometry(QRect(470, 30, 98, 27));
        isbn_insert_lab = new QLabel(MgrFrame);
        isbn_insert_lab->setObjectName(QString::fromUtf8("isbn_insert_lab"));
        isbn_insert_lab->setGeometry(QRect(40, 290, 66, 17));
        isbn_insert_edit = new QLineEdit(MgrFrame);
        isbn_insert_edit->setObjectName(QString::fromUtf8("isbn_insert_edit"));
        isbn_insert_edit->setGeometry(QRect(80, 290, 113, 27));
        cnt_insert_lab = new QLabel(MgrFrame);
        cnt_insert_lab->setObjectName(QString::fromUtf8("cnt_insert_lab"));
        cnt_insert_lab->setGeometry(QRect(230, 290, 66, 17));
        cnt_insert_edit = new QLineEdit(MgrFrame);
        cnt_insert_edit->setObjectName(QString::fromUtf8("cnt_insert_edit"));
        cnt_insert_edit->setGeometry(QRect(290, 290, 113, 27));
        insert_btn = new QPushButton(MgrFrame);
        insert_btn->setObjectName(QString::fromUtf8("insert_btn"));
        insert_btn->setGeometry(QRect(470, 280, 98, 27));
        destory_btn = new QPushButton(MgrFrame);
        destory_btn->setObjectName(QString::fromUtf8("destory_btn"));
        destory_btn->setGeometry(QRect(470, 330, 98, 27));
        isbn_destory_lab = new QLabel(MgrFrame);
        isbn_destory_lab->setObjectName(QString::fromUtf8("isbn_destory_lab"));
        isbn_destory_lab->setGeometry(QRect(40, 330, 66, 17));
        cnt_destory_lab = new QLabel(MgrFrame);
        cnt_destory_lab->setObjectName(QString::fromUtf8("cnt_destory_lab"));
        cnt_destory_lab->setGeometry(QRect(230, 330, 66, 17));
        cnt_destory_edit = new QLineEdit(MgrFrame);
        cnt_destory_edit->setObjectName(QString::fromUtf8("cnt_destory_edit"));
        cnt_destory_edit->setGeometry(QRect(290, 330, 113, 27));
        isbn_destory_edit = new QLineEdit(MgrFrame);
        isbn_destory_edit->setObjectName(QString::fromUtf8("isbn_destory_edit"));
        isbn_destory_edit->setGeometry(QRect(80, 330, 113, 27));
        tel_ret_edit = new QLineEdit(MgrFrame);
        tel_ret_edit->setObjectName(QString::fromUtf8("tel_ret_edit"));
        tel_ret_edit->setGeometry(QRect(80, 70, 113, 27));
        ret_btn = new QPushButton(MgrFrame);
        ret_btn->setObjectName(QString::fromUtf8("ret_btn"));
        ret_btn->setGeometry(QRect(470, 80, 98, 27));
        tel_ret_lab = new QLabel(MgrFrame);
        tel_ret_lab->setObjectName(QString::fromUtf8("tel_ret_lab"));
        tel_ret_lab->setGeometry(QRect(40, 70, 66, 17));
        isbn_ret_lab = new QLabel(MgrFrame);
        isbn_ret_lab->setObjectName(QString::fromUtf8("isbn_ret_lab"));
        isbn_ret_lab->setGeometry(QRect(230, 80, 66, 17));
        isbn_ret_edit = new QLineEdit(MgrFrame);
        isbn_ret_edit->setObjectName(QString::fromUtf8("isbn_ret_edit"));
        isbn_ret_edit->setGeometry(QRect(290, 80, 113, 27));
        star_ret_lab = new QLabel(MgrFrame);
        star_ret_lab->setObjectName(QString::fromUtf8("star_ret_lab"));
        star_ret_lab->setGeometry(QRect(40, 120, 66, 17));
        star_ret_edit = new QLineEdit(MgrFrame);
        star_ret_edit->setObjectName(QString::fromUtf8("star_ret_edit"));
        star_ret_edit->setGeometry(QRect(80, 120, 113, 27));
        mark_ret_txt = new QTextEdit(MgrFrame);
        mark_ret_txt->setObjectName(QString::fromUtf8("mark_ret_txt"));
        mark_ret_txt->setGeometry(QRect(230, 120, 341, 78));
        mark_ret_txt->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        add_btn = new QPushButton(MgrFrame);
        add_btn->setObjectName(QString::fromUtf8("add_btn"));
        add_btn->setGeometry(QRect(530, 220, 98, 27));
        tel_add_lab = new QLabel(MgrFrame);
        tel_add_lab->setObjectName(QString::fromUtf8("tel_add_lab"));
        tel_add_lab->setGeometry(QRect(20, 220, 66, 17));
        ya_add_lab = new QLabel(MgrFrame);
        ya_add_lab->setObjectName(QString::fromUtf8("ya_add_lab"));
        ya_add_lab->setGeometry(QRect(180, 230, 66, 17));
        ya_add_edit = new QLineEdit(MgrFrame);
        ya_add_edit->setObjectName(QString::fromUtf8("ya_add_edit"));
        ya_add_edit->setGeometry(QRect(220, 220, 113, 27));
        tel_add_edit = new QLineEdit(MgrFrame);
        tel_add_edit->setObjectName(QString::fromUtf8("tel_add_edit"));
        tel_add_edit->setGeometry(QRect(50, 220, 113, 27));
        yu_add_edit = new QLineEdit(MgrFrame);
        yu_add_edit->setObjectName(QString::fromUtf8("yu_add_edit"));
        yu_add_edit->setGeometry(QRect(400, 220, 113, 27));
        yu_add_lab = new QLabel(MgrFrame);
        yu_add_lab->setObjectName(QString::fromUtf8("yu_add_lab"));
        yu_add_lab->setGeometry(QRect(360, 230, 66, 17));
        yu_add_lab->raise();
        tel_ret_lab->raise();
        rollback_btn->raise();
        tel_borror_lab->raise();
        tel_borrow_edit->raise();
        isbn_borrow_lab->raise();
        isbn_borrow_edit->raise();
        borrow_btn->raise();
        isbn_insert_lab->raise();
        isbn_insert_edit->raise();
        cnt_insert_lab->raise();
        cnt_insert_edit->raise();
        insert_btn->raise();
        destory_btn->raise();
        isbn_destory_lab->raise();
        cnt_destory_lab->raise();
        cnt_destory_edit->raise();
        isbn_destory_edit->raise();
        tel_ret_edit->raise();
        ret_btn->raise();
        isbn_ret_lab->raise();
        isbn_ret_edit->raise();
        star_ret_lab->raise();
        star_ret_edit->raise();
        mark_ret_txt->raise();
        add_btn->raise();
        tel_add_lab->raise();
        ya_add_lab->raise();
        ya_add_edit->raise();
        tel_add_edit->raise();
        yu_add_edit->raise();

        retranslateUi(MgrFrame);

        QMetaObject::connectSlotsByName(MgrFrame);
    } // setupUi

    void retranslateUi(QFrame *MgrFrame)
    {
        MgrFrame->setWindowTitle(QApplication::translate("MgrFrame", "Frame", 0, QApplication::UnicodeUTF8));
        rollback_btn->setText(QApplication::translate("MgrFrame", "<<--", 0, QApplication::UnicodeUTF8));
        tel_borror_lab->setText(QApplication::translate("MgrFrame", "tel", 0, QApplication::UnicodeUTF8));
        isbn_borrow_lab->setText(QApplication::translate("MgrFrame", "ISBN", 0, QApplication::UnicodeUTF8));
        borrow_btn->setText(QApplication::translate("MgrFrame", "\345\200\237\344\271\246", 0, QApplication::UnicodeUTF8));
        isbn_insert_lab->setText(QApplication::translate("MgrFrame", "ISBN", 0, QApplication::UnicodeUTF8));
        cnt_insert_lab->setText(QApplication::translate("MgrFrame", "\346\225\260\351\207\217", 0, QApplication::UnicodeUTF8));
        insert_btn->setText(QApplication::translate("MgrFrame", "\345\205\245\345\272\223", 0, QApplication::UnicodeUTF8));
        destory_btn->setText(QApplication::translate("MgrFrame", "\346\212\245\346\215\237", 0, QApplication::UnicodeUTF8));
        isbn_destory_lab->setText(QApplication::translate("MgrFrame", "ISBN", 0, QApplication::UnicodeUTF8));
        cnt_destory_lab->setText(QApplication::translate("MgrFrame", "\346\225\260\351\207\217", 0, QApplication::UnicodeUTF8));
        ret_btn->setText(QApplication::translate("MgrFrame", "\350\277\230\344\271\246", 0, QApplication::UnicodeUTF8));
        tel_ret_lab->setText(QApplication::translate("MgrFrame", "tel", 0, QApplication::UnicodeUTF8));
        isbn_ret_lab->setText(QApplication::translate("MgrFrame", "ISBN", 0, QApplication::UnicodeUTF8));
        star_ret_lab->setText(QApplication::translate("MgrFrame", "Star", 0, QApplication::UnicodeUTF8));
        add_btn->setText(QApplication::translate("MgrFrame", "\346\267\273\345\212\240", 0, QApplication::UnicodeUTF8));
        tel_add_lab->setText(QApplication::translate("MgrFrame", "tel", 0, QApplication::UnicodeUTF8));
        ya_add_lab->setText(QApplication::translate("MgrFrame", "\346\212\274\351\207\221", 0, QApplication::UnicodeUTF8));
        yu_add_lab->setText(QApplication::translate("MgrFrame", "\344\275\231\351\242\235", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MgrFrame: public Ui_MgrFrame {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MGR_FRAME_H
