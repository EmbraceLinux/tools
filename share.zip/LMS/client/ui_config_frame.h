/********************************************************************************
** Form generated from reading UI file 'config_frame.ui'
**
** Created: Tue Sep 24 14:58:03 2019
**      by: Qt User Interface Compiler version 4.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CONFIG_FRAME_H
#define UI_CONFIG_FRAME_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QFrame>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_ConfigFrame
{
public:
    QPushButton *rollback_btn;
    QPushButton *save_reboo_btn;
    QLabel *serverIP_lab;
    QLabel *serverPort_lab;
    QLineEdit *serverIP_edit;
    QLineEdit *serverPort_edit;

    void setupUi(QFrame *ConfigFrame)
    {
        if (ConfigFrame->objectName().isEmpty())
            ConfigFrame->setObjectName(QString::fromUtf8("ConfigFrame"));
        ConfigFrame->resize(700, 400);
        ConfigFrame->setStyleSheet(QString::fromUtf8("QFrame\n"
"{\n"
"	background-color: rgb(236, 235, 234);\n"
"}\n"
"QPushButton:hover\n"
"{\n"
"	background-color: qconicalgradient(cx:0.5, cy:0.522909, angle:179.9, stop:0.494318 rgba(181, 225, 250, 255), stop:0.5 rgba(222, 242, 251, 255));\n"
"	border-radius:5px;\n"
"	border: 1px solid #3C80B1;  \n"
"}\n"
"\n"
"QPushButton:pressed\n"
"{\n"
"	background-color: qconicalgradient(cx:0.5, cy:0.522909, angle:179.9, stop:0.494318 rgba(134, 198, 233, 255), stop:0.5 rgba(206, 234, 248, 255));\n"
"	border-radius:5px;\n"
"	border: 1px solid #5F92B2;  \n"
"}"));
        ConfigFrame->setFrameShape(QFrame::StyledPanel);
        ConfigFrame->setFrameShadow(QFrame::Raised);
        rollback_btn = new QPushButton(ConfigFrame);
        rollback_btn->setObjectName(QString::fromUtf8("rollback_btn"));
        rollback_btn->setGeometry(QRect(590, 360, 98, 27));
        save_reboo_btn = new QPushButton(ConfigFrame);
        save_reboo_btn->setObjectName(QString::fromUtf8("save_reboo_btn"));
        save_reboo_btn->setGeometry(QRect(470, 360, 98, 27));
        serverIP_lab = new QLabel(ConfigFrame);
        serverIP_lab->setObjectName(QString::fromUtf8("serverIP_lab"));
        serverIP_lab->setGeometry(QRect(140, 70, 66, 17));
        serverPort_lab = new QLabel(ConfigFrame);
        serverPort_lab->setObjectName(QString::fromUtf8("serverPort_lab"));
        serverPort_lab->setGeometry(QRect(140, 130, 91, 17));
        serverIP_edit = new QLineEdit(ConfigFrame);
        serverIP_edit->setObjectName(QString::fromUtf8("serverIP_edit"));
        serverIP_edit->setGeometry(QRect(210, 70, 113, 27));
        serverPort_edit = new QLineEdit(ConfigFrame);
        serverPort_edit->setObjectName(QString::fromUtf8("serverPort_edit"));
        serverPort_edit->setGeometry(QRect(220, 120, 113, 27));

        retranslateUi(ConfigFrame);

        QMetaObject::connectSlotsByName(ConfigFrame);
    } // setupUi

    void retranslateUi(QFrame *ConfigFrame)
    {
        ConfigFrame->setWindowTitle(QApplication::translate("ConfigFrame", "Frame", 0, QApplication::UnicodeUTF8));
        rollback_btn->setText(QApplication::translate("ConfigFrame", "<<--", 0, QApplication::UnicodeUTF8));
        save_reboo_btn->setText(QApplication::translate("ConfigFrame", "\344\277\235\345\255\230\345\271\266\351\207\215\345\220\257", 0, QApplication::UnicodeUTF8));
        serverIP_lab->setText(QApplication::translate("ConfigFrame", "server IP", 0, QApplication::UnicodeUTF8));
        serverPort_lab->setText(QApplication::translate("ConfigFrame", "server port", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class ConfigFrame: public Ui_ConfigFrame {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CONFIG_FRAME_H
