#include "mgr_frame.h"
#include "ui_mgr_frame.h"
#include "json.h"

MgrFrame::MgrFrame(QWidget *parent) :
    QFrame(parent),
    ui(new Ui::MgrFrame)
{
    ui->setupUi(this);
}

MgrFrame::~MgrFrame()
{
    delete ui;
}

void MgrFrame::on_rollback_btn_clicked()
{
    this->hide();
}

void MgrFrame::on_borrow_btn_clicked()
{
    JSON* j1 = new JSON;
    j1->addObject("object","manager");
    j1->addObject("opt","borrow");

    JSON* j2 = new JSON;
    j2->addObject("tel",ui->tel_borrow_edit->text().toStdString().c_str());
    j2->addObject("isbn", ui->isbn_borrow_edit->text().toStdString().c_str());
    j1->addSubJSON("data",*j2);

    qDebug("json:%s",j1->getStr());
}

void MgrFrame::on_ret_btn_clicked()
{
    JSON* j1 = new JSON;
    j1->addObject("object","manager");
    j1->addObject("opt","ret");

    JSON* j2 = new JSON;
    j2->addObject("tel",ui->tel_ret_edit->text().toStdString().c_str());
    j2->addObject("isbn", ui->isbn_ret_edit->text().toStdString().c_str());
    j2->addObject("star", ui->star_ret_edit->text().toFloat());
    j2->addObject("mark", ui->mark_ret_txt->toPlainText().toStdString().c_str());
    j1->addSubJSON("data",*j2);

    qDebug("json:%s",j1->getStr());
}

void MgrFrame::on_add_btn_clicked()
{
    JSON* j1 = new JSON;
    j1->addObject("object","manager");
    j1->addObject("opt","add");

    JSON* j2 = new JSON;
    j2->addObject("tel",ui->tel_add_edit->text().toStdString().c_str());
    j2->addObject("ya", ui->ya_add_edit->text().toStdString().c_str());
    j2->addObject("yu", ui->yu_add_edit->text().toStdString().c_str());
    j1->addSubJSON("data",*j2);

    qDebug("json:%s",j1->getStr());
}

void MgrFrame::on_insert_btn_clicked()
{
    JSON* j1 = new JSON;
    j1->addObject("object","manager");
    j1->addObject("opt","insert");

    JSON* j2 = new JSON;
    j2->addObject("isbn",ui->isbn_insert_edit->text().toStdString().c_str());
    j2->addObject("cnt", ui->cnt_insert_edit->text().toStdString().c_str());
    j1->addSubJSON("data",*j2);

    qDebug("json:%s",j1->getStr());
}

void MgrFrame::on_destory_btn_clicked()
{
    JSON* j1 = new JSON;
    j1->addObject("object","manager");
    j1->addObject("opt","destory");

    JSON* j2 = new JSON;
    j2->addObject("isbn",ui->isbn_destory_edit->text().toStdString().c_str());
    j2->addObject("cnt", ui->cnt_destory_edit->text().toStdString().c_str());
    j1->addSubJSON("data",*j2);

    qDebug("json:%s",j1->getStr());
}
