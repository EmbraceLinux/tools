/********************************************************************************
** Form generated from reading UI file 'main_widget.ui'
**
** Created: Tue Sep 24 11:01:46 2019
**      by: Qt User Interface Compiler version 4.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAIN_WIDGET_H
#define UI_MAIN_WIDGET_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWidget
{
public:
    QPushButton *admin_btn;
    QPushButton *mgr_btn;
    QPushButton *guest_btn;
    QPushButton *config_btn;

    void setupUi(QWidget *MainWidget)
    {
        if (MainWidget->objectName().isEmpty())
            MainWidget->setObjectName(QString::fromUtf8("MainWidget"));
        MainWidget->resize(700, 400);
        admin_btn = new QPushButton(MainWidget);
        admin_btn->setObjectName(QString::fromUtf8("admin_btn"));
        admin_btn->setGeometry(QRect(60, 170, 100, 60));
        mgr_btn = new QPushButton(MainWidget);
        mgr_btn->setObjectName(QString::fromUtf8("mgr_btn"));
        mgr_btn->setGeometry(QRect(220, 170, 100, 60));
        guest_btn = new QPushButton(MainWidget);
        guest_btn->setObjectName(QString::fromUtf8("guest_btn"));
        guest_btn->setGeometry(QRect(380, 170, 100, 60));
        config_btn = new QPushButton(MainWidget);
        config_btn->setObjectName(QString::fromUtf8("config_btn"));
        config_btn->setGeometry(QRect(540, 170, 100, 60));

        retranslateUi(MainWidget);

        QMetaObject::connectSlotsByName(MainWidget);
    } // setupUi

    void retranslateUi(QWidget *MainWidget)
    {
        MainWidget->setWindowTitle(QApplication::translate("MainWidget", "MainWidget", 0, QApplication::UnicodeUTF8));
        admin_btn->setText(QApplication::translate("MainWidget", "\350\266\205\347\272\247\347\256\241\347\220\206\345\221\230", 0, QApplication::UnicodeUTF8));
        mgr_btn->setText(QApplication::translate("MainWidget", "\347\256\241\347\220\206\345\221\230", 0, QApplication::UnicodeUTF8));
        guest_btn->setText(QApplication::translate("MainWidget", "\346\270\270\345\256\242", 0, QApplication::UnicodeUTF8));
        config_btn->setText(QApplication::translate("MainWidget", "\351\205\215\347\275\256", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class MainWidget: public Ui_MainWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAIN_WIDGET_H
