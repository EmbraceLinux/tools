#include "admin_frame.h"
#include "ui_admin_frame.h"
#include "json.h"
#include "main_widget.h"

AdminFrame::AdminFrame(QWidget *parent) :
    QFrame(parent),
    ui(new Ui::AdminFrame)
{
    ui->setupUi(this);
}

AdminFrame::~AdminFrame()
{
    delete ui;
}

// 接收服务端的处理结果
void AdminFrame::recv_server_result(void)
{
    tcpSocket->waitForReadyRead();
    char buf[4096] = {};
    tcpSocket->read(buf,sizeof(buf));
    // 解析JSON
    // 添加 弹出提示框
    // 删除 弹出提示框
    // 重置 弹出提示框
    // 列出所有 循环接收id和pw
}

void AdminFrame::on_rollback_btn_clicked()
{
    this->hide();
}

void AdminFrame::on_delMgr_btn_clicked()
{
    JSON* j1 = new JSON;
    j1->addObject("object","admin");
    j1->addObject("opt","del");
    j1->addObject("data",ui->delMgr_edit->text().toStdString().c_str());
    tcpSocket->write(j1->getStr(),strlen(j1->getStr())+1);
    tcpSocket->waitForBytesWritten();
    qDebug("json:%s",j1->getStr());
}

void AdminFrame::on_reSetPW_btn_clicked()
{
    JSON* j1 = new JSON;
    j1->addObject("object","admin");
    j1->addObject("opt","reset");
    tcpSocket->write(j1->getStr(),strlen(j1->getStr())+1);
    tcpSocket->waitForBytesWritten();
    qDebug("json:%s",j1->getStr());
}

void AdminFrame::on_addMgr_btn_clicked()
{
    JSON* j1 = new JSON;
    j1->addObject("object","admin");
    j1->addObject("opt","add");

    tcpSocket->write(j1->getStr(),strlen(j1->getStr())+1);
    tcpSocket->waitForBytesWritten();
    qDebug("json:%s",j1->getStr());
}

void AdminFrame::on_listAllMgr_btn_clicked()
{
    JSON* j1 = new JSON;
    j1->addObject("object","admin");
    j1->addObject("opt","list");
    tcpSocket->write(j1->getStr(),strlen(j1->getStr())+1);
    tcpSocket->waitForBytesWritten();
    qDebug("json:%s %d",j1->getStr());
}
