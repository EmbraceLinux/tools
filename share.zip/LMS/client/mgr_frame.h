#ifndef MGR_FRAME_H
#define MGR_FRAME_H

#include <QFrame>

namespace Ui {
class MgrFrame;
}

class MgrFrame : public QFrame
{
    Q_OBJECT
    
public:
    explicit MgrFrame(QWidget *parent = 0);
    ~MgrFrame();
    
private slots:
    void on_rollback_btn_clicked();

    void on_borrow_btn_clicked();

    void on_ret_btn_clicked();

    void on_add_btn_clicked();

    void on_insert_btn_clicked();

    void on_destory_btn_clicked();

private:
    Ui::MgrFrame *ui;
};

#endif // MGR_FRAME_H
