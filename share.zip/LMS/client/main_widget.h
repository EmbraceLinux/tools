#ifndef MAIN_WIDGET_H
#define MAIN_WIDGET_H

#include <QWidget>
#include <QTcpSocket>
#include "admin_frame.h"
#include "mgr_frame.h"
#include "guest_frame.h"
#include "config_frame.h"

extern QTcpSocket* tcpSocket;

namespace Ui {
class MainWidget;
}

class MainWidget : public QWidget
{
    Q_OBJECT
    
    // 超级管理员界面
    AdminFrame*     adminFrame;
    // 管理员界面
    MgrFrame*       mgrFrame;
    // 游客界面
    GuestFrame*     guestFrame;
    // 配置文件界面
    ConfigFrame*    configFrame;

public:
    explicit MainWidget(QWidget *parent = 0);
    ~MainWidget();

private slots:
    void on_admin_btn_clicked();

    void on_mgr_btn_clicked();

    void on_guest_btn_clicked();

    void on_config_btn_clicked();

    void connect_server_success();

    void connect_server_error(QAbstractSocket::SocketError err);

private:
    Ui::MainWidget *ui;
};

#endif // MAIN_WIDGET_H
