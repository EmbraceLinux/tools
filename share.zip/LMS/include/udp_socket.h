#ifndef UDP_SOCKET_H
#define UDP_SOCKET_H
#include "base_socket.h"

// UDP基础类 继承BaseSocket类fd、addr、addlen
class UdpSocket:public BaseSocket
{
public:
	// 显示调用父类构造，创建socket描述符和初始化网络地址已经在父类构造完成
	UdpSocket(const char* ip,uint16_t port):BaseSocket(SOCK_DGRAM,ip,port) {}
	
	// UDP协议专用的接收数据
	int recv(void* buf,uint32_t len)
	{
		return recvfrom(fd,buf,len,0,(SP)&addr,&addrlen);
	}
	
	// UDP协议专用的发送数据
	int send(void* buf,uint32_t len)
	{
		return sendto(fd,buf,len,0,(SP)&addr,addrlen);
	}
	
	// 如果发送的数据是字符串，可以函数自己计算字符串长度，重载
	int send(const char* buf)
	{
		return sendto(fd,buf,strlen(buf)+1,0,(SP)&addr,addrlen);
	}
};

// UDP服务端类 继承UdpSocket类fd、addr、addlen、recv/send
class UdpServer:public UdpSocket
{
public:
	// 显式调用父类构造 UdpServer->UdpSocket->BaseSocket
	UdpServer(const char* ip,uint16_t port):UdpSocket(ip,port)
	{
		// socket描述符与网络地址结构体绑定，绑定完成后addr已经无用，可以在其它步骤中重复使用
		if(bind(fd,(SP)&addr,addrlen))
    	{
        	perror("UdpServer bind");
    	}
	}
};

// UDP客户端类 继承UdpSocket类fd、addr、addlen 隐藏UdpSocket类recv/send
class UdpClient:public UdpSocket
{
public:
	// 显式调用父类构造 UdpClient->UdpSocket->BaseSocket
	UdpClient(const char* ip,uint16_t port):UdpSocket(ip,port)
	{
		// 可以提高通信时的速度，发送／接收数据时可以使用recv/send函数，也可以继续使用recvfrom/sendto
		if(connect(fd,(SP)&addr,addrlen))
    	{
        	perror("UdpClient connect");
    	}
	}
	
	// 由于已经调用过connect,因此可以使用recv函数
	int recv(void* buf,uint32_t len)
	{
		// C＋＋中的全局函数、变量会默认添加到匿名的名字空间中 :: 
		// 由于recv函数与socket中的recv重名编译器无法区别，因此使用域限定符告诉编译器使用的是socket中的recv函数
		return ::recv(fd,buf,len,0);
	}
	
	int send(void* buf,uint32_t len)
	{
		return ::send(fd,buf,len,0);
	}
	
	int send(const char* buf)
	{
		return ::send(fd,buf,strlen(buf)+1,0);
	}
};

#endif//UDP_SOCKET_H
