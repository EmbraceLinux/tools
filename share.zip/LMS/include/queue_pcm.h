#ifndef QUEUE_PCM_H
#define QUEUE_PCM_H
#include <pthread.h>

template <typename T>
class QueuePCM
{
	// 存储任务的数组
	T* arr;
	// 队列的容量
	int cal;
	// 队列中存储任务数量
	int cnt;
	// 队头下标
	int head;
	// 队尾下标
	int tail;
	
	// 互斥锁
	pthread_mutex_t lock;
	// 当队列满时的睡眠条件
	pthread_cond_t  cond_full;
	// 当队列空时的睡眠条件
	pthread_cond_t  cond_empty;
public:
	QueuePCM(int cal=10):cal(cal)
	{
		// 从堆中创建存储任务的数组
		arr = new T[cal];
		// 初始化队列的数量
		cnt = 0;
		// 初始化队头下标
		head = 0;
		// 初始化队尾下标
		tail = -1;
		// 初始化互斥锁
		pthread_mutex_init(&lock,NULL);
		// 初始化条件变量
		pthread_cond_init(&cond_full,NULL);
		pthread_cond_init(&cond_empty,NULL);
	}

	~QueuePCM(void)
	{
		// 销毁任务数组
		delete[] arr;
		// 销毁互斥锁、条件变量
		pthread_mutex_destroy(&lock);
		pthread_cond_destroy(&cond_full);
		pthread_cond_destroy(&cond_empty);
	}

	// 判断队列是否为空
	bool empty(void)
	{
		return 0 == cnt;
	}

	// 判断队列是否满
	bool full(void)
	{
		return cnt >= cal;
	}

	// 任务入队
	void push(const T& elem)
	{
		// 加锁
		pthread_mutex_lock(&lock);
		
		// 如果队列已经满则睡眠并解锁
		while(full())
		{
			pthread_cond_wait(&cond_full,&lock);
		}
		
		// 如果能够醒来说明队列不满，则向队列中添加任务
		tail = (tail+1) % cal;
		arr[tail] = elem;
		// 任务数量加1
		cnt++;
		
		// 通知 队列空时睡眠的线程 醒来
		pthread_cond_signal(&cond_empty);
		// 解锁
		pthread_mutex_unlock(&lock);
	}

	T pop(void)
	{
		// 加锁
		pthread_mutex_lock(&lock);
		
		// 如果队列为空则睡眠并解锁
		while(empty())
		{
			pthread_cond_wait(&cond_empty,&lock);
		}

		// 如果线程能够醒来则说明队列中已经有任务，从队头弹出一个任务
		T* elem = arr + head++;
		// 任务数量减1
		cnt--;
		
		// 通知 队列满时睡眠的线程 醒来
		pthread_cond_signal(&cond_full);
		// 解锁
		pthread_mutex_unlock(&lock);
		// 返回任务
		return *elem;
	}
};

#endif//QUEUE_PCM_H
