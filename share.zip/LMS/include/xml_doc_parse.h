#ifndef XML_DOC_PARSE_H
#define XML_DOC_PARSE_H
#include <map>
#include <string>
#include "tinyxml.h"

using namespace std;

class XmlDocParse
{
	// xml文件的路径
	const char* path;
	// 记录xml文件的解析结构
	map<string,string> env;
	// xml对象，它的构造函数需要使用到xml文件的路径
	TiXmlDocument* doc;	
	// xml解析函数，不需要外界调用
	void parse(void);
public:
	// 创建时可以提供xml文件路径
	XmlDocParse(const char* path=NULL);
	~XmlDocParse(void);
	
	// 显式设置xml文件路径
	void setPath(const char* path);
	// 根据对象名获取对象值
	const char* getValue(string name);
};

#endif//XML_DOC_PARSE_H
