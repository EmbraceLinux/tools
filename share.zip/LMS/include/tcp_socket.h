#ifndef TCP_SOCKET_H
#define TCP_SOCKET_H
#include "base_socket.h"

// TCP基础类 继承BaseSocket类fd、addr、addlen
class TcpSocket:public BaseSocket
{	
public:
	// 为accetp创建客户端连接服务的 TcpSocket->BaseSocket
	TcpSocket(int fd,struct sockaddr_in& addr):BaseSocket(fd,addr) {}
	
	// 显式调用父构造 TcpSocket->BaseSocket
	TcpSocket(const char* ip,uint16_t port):BaseSocket(SOCK_STREAM,ip,port) {}
	
	// 数据接收函数，调用了socket中的recv函数
	int recv(void* buf,uint32_t len)
	{
		return ::recv(fd,buf,len,0);
	}	
	
	int send(void* buf,uint32_t len)
	{
		return ::send(fd,buf,len,0);
	}
	
	int send(const char* buf)
	{
		return ::send(fd,buf,strlen(buf),0);
	}
};

// TCP服务端类 继承TcpSocket类fd、addr、addlen、recv/send
class TcpServer:public TcpSocket
{
public:
	// 显式调用父类构造 TcpServer->TcpSocket->BaseSocket
	TcpServer(const char* ip,uint16_t port,uint8_t listen_cnt=50):TcpSocket(ip,port)
	{
		// 绑定socket与网络地址结构体，绑定完成后，addr也会进行复用
		if(bind(fd,(SP)&addr,addrlen))
    	{
        	elog("TcpServer bind:%s\n",strerror (errno));
        	return;
    	}
    	ilog("绑定socket与网络地址结构体成功...\n");
    	
    	// 设置监听
    	if(listen(fd,listen_cnt))
    	{
    		elog("TcpServer listen:%s\n",strerror (errno));
    		return;
    	}
    	ilog("socket设置监听成功...\n");
	}
	
	// 等待客户端连接，返回一个新的TcpSocket对象
	TcpSocket* accept(void)
	{
		int clifd = ::accept(fd,(SP)&addr,&addrlen);
		if(0 > clifd)
		{
			elog("TcpServer accept:%s\n",strerror (errno));
			return NULL;
		}
		ilog("有新的客户端连接成功,%s...\n",inet_ntoa(addr.sin_addr));
		// 调用TcpSocket(int,struct sockaddr_in&)->BaseSocket(int fd,struct sockaddr_in&)
		return new TcpSocket(clifd,addr);
	}
};

// TCP客户端类 继承TcpSocket类fd、addr、addlen、recv/send
class TcpClient:public TcpSocket
{
public:
	// 显式调用父类的构造 TcpClient->TcpSocket->BaseSocket
	TcpClient(const char* ip,uint16_t port):TcpSocket(ip,port)
	{
		if(connect(fd,(SP)&addr,addrlen))
    	{
        	elog("TcpClient connect:%s\n",strerror (errno));
        	return;
    	}
    	ilog("客户端连接服务器成功,%s...\n",inet_ntoa(addr.sin_addr));
	}
};



#endif//TCP_SOCKET_H
