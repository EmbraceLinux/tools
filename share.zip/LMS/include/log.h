// 日志用来记录提示信息、警告、错误、致命错误的
#ifndef LOG_H
#define LOG_H
#include <stdio.h>
#include <string.h>
#include <errno.h>

// 日志的级别
typedef enum LOG_LEVEL{
	LOG_FATAL,		// 记录致命错误
	LOG_ERROR,		// 记录错误和致命错误
	LOG_WARNING,	// 记录警告、错误和致命错误
	LOG_INFO		// 记录所有提示信息
}LOG_LEVEL;

// 声明存储日志级别的全局变量
extern LOG_LEVEL log_level;

/*
	用来存储提示、警告、错误、致命错误的文件指针
	如果没有调用则说明项目处理调试阶段则它们值为stdout或stderr
	如果调用set_log_path，则它们都指向一个打开的文件，这些信息会被记录到日志文件中
*/
extern FILE* ifp;
extern FILE* wfp;
extern FILE* efp;
extern FILE* ffp;

// 设置日志文件文件的路径
int set_log_path(const char* log_path,const char* program);

// 设置日志信息的显示级别
void set_log_level(const char* log_level);

// 提示信息，用法与printf一致，根据日志级别判断提示信息是否显示
#define ilog(fmt, ...) \
{\
	if(log_level >= LOG_INFO)\
	{\
		fprintf(ifp,"File:%s Fine:%u: Info:",__FILE__,__LINE__);\
		fprintf(ifp,fmt,##__VA_ARGS__);\
	}\
}

// 警告信息，用法与printf一致，根据日志级别判断警告信息是否显示
#define wlog(fmt, ...) \
{\
	if(log_level >= LOG_WARNING)\
	{\
		fprintf(wfp,"File:%s Fine:%u: Warning:",__FILE__,__LINE__);\
		fprintf(wfp,fmt,##__VA_ARGS__);\
	}\
}

// 错误信息，用法与printf一致，根据日志级别判断错误信息是否显示
#define elog(fmt, ...) \
{\
	if(log_level >= LOG_ERROR)\
	{\
		fprintf(efp,"File:%s Fine:%u: Error:",__FILE__,__LINE__);\
		fprintf(efp,fmt,##__VA_ARGS__);\
	}\
}

// 致命错误信息，用法与printf一致，此判断仅仅是为了好看
#define flog(fmt, ...) \
{\
	if(log_level >= LOG_FATAL)\
	{\
		fprintf(ffp,"File:%s Fine:%u: Fatal:",__FILE__,__LINE__);\
		fprintf(ffp,fmt,##__VA_ARGS__);\
	}\
}
#endif//LOG_H

