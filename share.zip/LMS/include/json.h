#ifndef JSON_H
#define JSON_H
#include "cJSON.h"

// 功能1：生成JSON对象(addObject添加各类型数据)->转换成字符串(调用getStr函数)->发送
// 功能2：从网络接收到字符串->字符串转换成JSON对象(parse)->转换出对应的值(getObject)
class JSON
{
	// 解析时需要的对象
	cJSON* root;
	// cJSON对象转换的结果
	char* str;
public:	
	JSON(void);
	
	~JSON(void);
	
	// 向cJSON对象插入cJSON对象时会调用到
	cJSON* getRoot(void);
	
	// 在cJSON对象查询cJSON对象会用到
	void setRoot(cJSON* root);
	
	// 获取parse转换的结果
	const char* getStr(void);
	
	// 把cJSON对象转换成字符串
	bool parse(const char* json_str);
	
	// 向cJSON对象插入一个字符串数据
	void addObject(const char* name,const char* data);
	
	// 向cJSON对象插入一个布尔数据
	void addObject(const char* name,bool data);
	
	// 向cJSON对象插入 char short int long float double 类型的数据，number可以兼容float和double，但转换时必须使用obj->valuedouble，否则小数点后的数据就会丢失。
	template<typename T> void addObject(const char* name,const T& data)
	{
		cJSON_AddNumberToObject(root,name,data);
	}
	
	// 向cJSON对象插入cJSON对象
	void addSubJSON(const char* name,JSON& obj);
	
	// 从cJSON对象获取字符串类型的值
	bool getObject(const char* name,char* data);
	
	// 从cJSON对象获取double类型的值
	bool getObject(const char* name,double& data);
	
	// 从cJSON对象获取子cJSON对象
	JSON* getSubJSON(const char* name);

	// 从cJSON对象获取char,short,int,long类型的值 
	template<typename T> bool getObject(const char* name,T& data)
	{
		cJSON* obj = cJSON_GetObjectItem(root,name);
		if(NULL == obj)
		{
        	printf("cJSON error %s\n",cJSON_GetErrorPtr());
			return false;
		}
		data = obj->valueint;
		return true;
	}
};
#endif//JSON_H
