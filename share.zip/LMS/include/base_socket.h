#ifndef BASE_SOCKET_H
#define BASE_SOCKET_H

#include <log.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

typedef struct sockaddr* SP;

class BaseSocket
{
protected:
	// socket 描述符
	int fd;
	// 网络地址结构体的字节数									
	socklen_t addrlen;
	// 网络通信地址：绑定(TCP/UDP server) 连接(TCP accept) 接收（UDP recvfrom/sentto）
	struct sockaddr_in addr;
	// TCP accept函数中创建新客户端连接
	BaseSocket(int fd,struct sockaddr_in& addr):fd(fd),addr(addr) {}
public:
	
	// type:SOCK_DGRAM/SOCK_STREAM 网络通信协议
	BaseSocket(int type,const char* ip,uint16_t port)
	{
		// 创建socket描述符
		fd = socket(AF_INET,type,0);
    	if(0 > fd)
    	{
        	elog("UdpServer socket:%s\n",strerror (errno));
        	return;
    	}
    	ilog("创建socket成功...\n");
    	
    	

		// 初始化网络地址、客口号
    	addr.sin_family = AF_INET;
    	addr.sin_port = htons(port);
    	addr.sin_addr.s_addr = inet_addr(ip);
    	// 计算网络地址结构体的字节数
    	addrlen = sizeof(addr);
	}
	
	~BaseSocket(void)
	{
		close(fd);
	}
	
	// 把整数型ip地址转换成字符串型的ip地址
	const char* getIP(void)
	{
		 return inet_ntoa(addr.sin_addr);
	}
	
	// 把网络字节序的端口号 转换成 本地字节序的端口号
	uint16_t getPort(void)
	{
		return ntohs(addr.sin_port);
	}
};

#endif//UDP_SOCKET_H
