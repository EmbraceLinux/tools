#ifndef MD5_H
#define MD5_H

typedef struct
{
	unsigned int count[2];
	unsigned int state[4];
	unsigned char buffer[64];
}MD5_CTX;

// 根据文件路径获取文件的MD5值
uint8_t* getmd5_path(const char* path,uint8_t encrypt[16]);

// 根据文件描述符获取文件的MD5值
uint8_t* getmd5_fd(int fd,uint8_t encrypt[16]);

// 根据文件指针获取文件的MD5值
uint8_t* getmd5_file(FILE* frp,uint8_t encrypt[16]);

// 根据字符串获取MD5值
uint8_t* getmd5_str(char* str,uint8_t encrypt[16]);

// 比较两个MD5值
int md5cmp(const uint8_t enc1[16],const uint8_t enc2[16]);

// 显示MD5值
void show_md5(const uint8_t encrypt[16]);

// 初始化MD5结构体
void MD5Init(MD5_CTX *context);

// 计算MD5值
void MD5Update(MD5_CTX *context,unsigned char *input,unsigned int inputlen);

// 拷贝出MD5值
void MD5Final(MD5_CTX *context,unsigned char digest[16]);
#endif

