#ifndef THREADPOOL_H
#define THREADPOOL_H
#include "queue_pcm.h"

typedef void* (*RunFP)(void*);
template <typename T>
class ThreadPool
{
	// 线程入口函数
	RunFP run;
	// 线程数量
	int count;
	// 存储线程ID的数组
	pthread_t* pids;	
	// 存储任务的队列
	QueuePCM<T> queue;
public:
	// 初始化线程入口函数，线程数量
	ThreadPool(RunFP run,int count=10):run(run),count(count)
	{
		pids = new pthread_t[count];
		ilog("初始化线程入口函数，线程数量为：%d...\n",count);
	}
	
	// 结束所有线程，销毁线程ID数组
	~ThreadPool(void)
	{
		stop();
		delete[] pids;
	}

	// 开启线程池，创建线程
	void start(void)
	{
		for(int i=0; i<count; i++)
		{
			pthread_create(pids+i,NULL,run,this);
			ilog("创建第%d个线程%lu...\n",i+1,pids[i]);
		}
	}

	// 停止所有线程
	void stop(void)
	{
		for(int i=0; i<count; i++)
		{
			// 向线程发送取消操作（线程默认会响应(结束)）
			pthread_cancel(pids[i]);
			// 等待线程结束，并回收线程资源
			pthread_join(pids[i],NULL);
		}
	}

	// 向任务队列添加任务
	void pushTask(const T& elem)
	{
		queue.push(elem);
	}
	
	// 从任务队列弹出任务
	T popTask(void)
	{
		return queue.pop();
	}
};

#endif//THREADPOOL_H
